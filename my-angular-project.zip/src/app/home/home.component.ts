import { Component } from '@angular/core';
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { NavigationComponent } from "../navigation/nav.component";
import {Router, RouterOutlet} from "@angular/router";
import {ProfileComponent} from "../profile/profile.component";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  standalone: true,
  imports: [
    RouterOutlet,
    HeaderComponent,
    FooterComponent,
    NavigationComponent,
    ProfileComponent
    // ... other imports
  ]
})
export class HomeComponent {
  constructor(private router: Router) {}

  onNavigate(route: string): void {
    // Logic to navigate to the selected route
    console.log('Navigating to:', route);

    switch (route) {
      case 'HOME':
        this.router.navigate(['home']);
        break;
      case 'PROFILE':
        this.router.navigate(['profile']);
        break;
      // Add other cases for different route names as needed
      default:
        console.error('Invalid route name:', route);
        break;
    }
  }
}
