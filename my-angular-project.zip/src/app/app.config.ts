import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';

import {RoutingModule, routes} from './routing.module';
//import {ContentRoutingModule} from "./content-routing.module";

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    RoutingModule, // Include RoutingModule
    //ContentRoutingModule, // Include AdminRoutingModule
  ]
};
